// PREMIER MENU -> noir
var menu1 = menuContext.Add( "MenuDegrade" )

	var itm = menu1.Add( "Images/File.gif", "Lien vers <B>Google</B>", "ItemDegrade", "ItemOnFocus" )
	itm.SetURL( "http://www.google.fr/" )
	itm.SetFunction( "ClickOnItem" )

	menu1.Add( "Images/File.gif", "Fichier 2", "ItemDegrade", "ItemOnFocus" ).SetFunction( "ClickOnItem" )

	menu1.Add( "Images/S�parateur.gif", "", "", "" ).SetFunction( "ClickOnItem" )

	// Ajoute un sous-menu (gr�ce � "MakeSubMenu") puis on r�cup�re l'instance sur le nouveau menu
	var itemSousMenu3 = menu1.Add( "Images/SousMenu.gif", "Menu", "ItemDegrade", "ItemOnFocus" )
	var sousMenu3 = itemSousMenu3.MakeSubMenu( "MenuDegrade", "Images/Fl�che.gif" )
	itemSousMenu3.SetImageOnFocus( "Images/SousMenuFocused.gif" )

		sousMenu3.Add( "", "Item 1", "ItemDegrade", "ItemOnFocus", "ClickOnItem" ).SetFunction( "ClickOnItem" )

		sousMenu3.Add( "Images/S�parateur.gif", "", "", "" ).SetFunction( "ClickOnItem" )
	
		var itemSousMenu3_0 = sousMenu3.Add( "Images/SousMenu.gif", "Dossier", "ItemDegrade", "ItemOnFocus" )
		var sousMenu3_0 = itemSousMenu3_0.MakeSubMenu( "MenuDegrade", "Images/Fl�che.gif" )
		itemSousMenu3_0.SetImageOnFocus( "Images/SousMenuFocused.gif" )

			sousMenu3_0.Add( "", "Item 1", "ItemDegrade", "ItemOnFocus" ).SetFunction( "ClickOnItem" )

			sousMenu3_0.Add( "", "Item 2", "ItemDegrade", "ItemOnFocus" ).SetFunction( "ClickOnItem" )

	var itemSousMenu2 = menu1.Add( "Images/SousMenu.gif", "Changer le menu", "ItemDegrade", "ItemOnFocus" )
	var sousMenu2 = itemSousMenu2.MakeSubMenu( "MenuDegrade", "Images/Fl�che.gif" )
	itemSousMenu2.SetImageOnFocus( "Images/SousMenuFocused.gif" )

		sousMenu2.Add( "", "Menu 1", "ItemDegrade", "ItemOnFocus" ).SetFunction( "ClickOnMenu" )

		sousMenu2.Add( "", "Menu 2", "ItemDegrade", "ItemOnFocus" ).SetFunction( "ClickOnMenu" )

		sousMenu2.Add( "", "Menu 3", "ItemDegrade", "ItemOnFocus" ).SetFunction( "ClickOnMenu" )

// DEUXIEME MENU -> vert
var menu2 = menuContext.Add( "MenuSimple" )

	menu2.Add( "", "Item avec un texte sur plusieurs lignes", "ItemSimple", "ItemSimpleOnFocus" )

	// Ajoute un sous-menu mais sans image de Fl�che dans l'item donc : ""
	var item1 = menu2.Add( "", "Sous menu 1", "ItemSimple", "ItemSimpleOnFocus" )
	var sousMenu20 = item1.MakeSubMenu( "MenuSimple", "Images/Fl�che verte.gif" )
	item1.SetFlecheOnFocus( "Images/Fl�che verte focus.gif" )

		sousMenu20.Add( "", "Item 1", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnItem" )

		sousMenu20.Add( "", "Item 2", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnItem" )

		sousMenu20.Add( "", "Item 3", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnItem" )

		sousMenu20.Add( "", "Item 4", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnItem" )

		sousMenu20.Add( "", "Item 5", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnItem" )

		var item2 = sousMenu20.Add( "Images/Dossier.gif", "Changer le menu", "ItemSimple", "ItemSimpleOnFocus" )
		var sousSousmenu20 = item2.MakeSubMenu( "MenuSimple", "Images/Fl�che verte.gif" )
		item2.SetFlecheOnFocus( "Images/Fl�che verte focus.gif" )

			sousSousmenu20.Add( "", "Menu 1", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnMenu" )

			sousSousmenu20.Add( "", "Menu 2", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnMenu" )

			sousSousmenu20.Add( "", "Menu 3", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnMenu" )

		var item3 = sousMenu20.Add( "", "Sous Menu", "ItemSimple", "ItemSimpleOnFocus" )
		var sousSousmenu21 = item3.MakeSubMenu( "MenuSimple", "Images/Fl�che verte.gif" )
		item3.SetFlecheOnFocus( "Images/Fl�che verte focus.gif" )

			sousSousmenu21.Add( "", "Item", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnItem" )

			var item4 = sousSousmenu21.Add( "", "Dernier menu", "ItemSimple", "ItemSimpleOnFocus" )
			var sousSousmenu210 = item4.MakeSubMenu( "MenuSimple", "Images/Fl�che verte.gif" )
			item4.SetFlecheOnFocus( "Images/Fl�che verte focus.gif" )

				sousSousmenu210.Add( "", "Item", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnItem" )

	var item5 = menu2.Add( "", "Sous menu 2", "ItemSimple", "ItemSimpleOnFocus" )
	var sousMenu21 = item5.MakeSubMenu( "MenuSimple", "Images/Fl�che verte.gif" )
	item5.SetFlecheOnFocus( "Images/Fl�che verte focus.gif" )

		sousMenu21.Add( "", "Item 1", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnItem" )

		sousMenu21.Add( "", "Item 2", "ItemSimple", "ItemSimpleOnFocus" ).SetFunction( "ClickOnItem" )

// TROISIEME MENU -> oranger / transparent
var menu3 = menuContext.Add( "MenuTransparent" )

	menu3.Add( "Images/smile1.gif", "Menu 1", "ItemTransparent", "ItemTransparentOnFocus" ).SetFunction( "ClickOnMenu" )

	menu3.Add( "Images/smile2.gif", "Menu 2", "ItemTransparent", "ItemTransparentOnFocus" ).SetFunction( "ClickOnMenu" )

	menu3.Add( "Images/smile3.gif", "Menu 3", "ItemTransparent", "ItemTransparentOnFocus" ).SetFunction( "ClickOnMenu" )
