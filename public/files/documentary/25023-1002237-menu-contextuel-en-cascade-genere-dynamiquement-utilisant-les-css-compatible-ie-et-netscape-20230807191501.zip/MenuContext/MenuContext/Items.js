//////////////////////////////////////////////////////////////////////////////////
//	OBJET	:	Classe et fonctions javascript, permettant la gestion d'un item	//
//				d'un menu contextuel d'une page DHTML							//
//	DATE	:	13 f�vrier 2005													//
//	AUTEUR	:	GOLINSKI Ludwig													//
//////////////////////////////////////////////////////////////////////////////////



// CLASSE REPRESENTANT UN ITEM D'UN MENU OU D'UN SOUS-MENU
function Item( indexItem, imageItem, texteItem, styleItem, styleOnFocus )
{
	// Index unique permettant d'identifier l'item
	this.index = indexItem

	// Image affich�e avant le texte de l'item (sans le focus)
	if( imageItem.length == 0 )
		this.image = "none"
	else
		this.image = imageItem

	// Image affich�e avant le texte de l'item (avec le focus)
	this.imageOnFocus = "none"

	// Style affect� � l'item (sans le focus)
	this.style = styleItem

	// Style affect� � l'item (avec le focus)
	this.styleOnFocus = styleOnFocus

	// Texte affich� dans l'item
	if( texteItem.length == 0 )
		this.texte = "none"
	else
		this.texte = texteItem

	// Nom de la fonction � appeler lors de la selection de l'item
	this.functionOnClick = "none"

	// URL � appeler lors de la selection de l'item
	this.URLOnClick = "none"

	// Nom de l'image de la fl�che (sans le focus)
	this.imageFleche = "none"

	// Nom de l'image de la fl�che (avec le focus)
	this.imageFlecheOnFocus = "none"

	// Instance sur le sous-menu de l'item
	this.sousMenu = null

	// M�thodes permettant la gestion interne de l'item
	this.Draw = Item_Draw
	this.MakeFocused = Item_MakeFocused
	this.MakeUnfocused = Item_MakeUnfocused

	// M�thodes permettant la configuration de l'item
	this.MakeSubMenu = Item_MakeSubMenu
	this.SetImageOnFocus = Item_SetImageOnFocus
	this.SetFlecheOnFocus = Item_SetFlecheOnFocus
	this.SetFunction = Item_SetFunction
	this.SetURL = Item_SetURL
}

// METHODE PERMETTANT DE DESSINER L'ITEM
function Item_Draw()
{
	// Cr�e la table repr�sentant l'item avec le style appropri�
	document.write( "<TABLE ID = 'ITEM_" + this.index + "' CLASS = '" + this.style + "' CELLPADDING = 0px CELLSPACING = 0px><TR>" );

	// L'item contient une image
	if( this.image != "none" )
		document.write( "<TD WIDTH = '1px'><IMG ID = 'IMG_ITEM_" + this.index + "' SRC = ' " + this.image + "'></TD>" )

	// L'item contient un texte
	if( this.texte != "none" )
		document.write( "<TD>" + this.texte + "</TD>" )

	// L'item contient un sous menu et une fl�che
	if( this.sousMenu != null && this.imageFleche != "none" )
		document.write( "<TD WIDTH = '1px'><IMG ID = 'FLECHE_ITEM_" + this.index + "' SRC = '" + this.imageFleche + "'></TD>" )

	// Referme la table
	document.write( "</TR></TABLE>" )
}



// METHODE PERMETTANT D'AFFECTER LE STYLE DEFINI LORSQUE L'ITEM A LE FOCUS
function Item_MakeFocused()
{
	// Change le style de l'item
	GetElement( "ITEM_" + this.index ).className = this.styleOnFocus

	// Modifie l'image situ� devant le texte de l'item
	if( this.image != "none" && this.imageOnFocus != "none" )
		GetElement( "IMG_ITEM_" + this.index ).src = this.imageOnFocus

	// Modifie l'image de la fl�che
	if( this.imageFlecheOnFocus != "none" )
		GetElement( "FLECHE_ITEM_" + this.index ).src = this.imageFlecheOnFocus

	// L'item doit rediriger la page lors d'un click
	if( this.URLOnClick != "none" )
		// Affiche le lien dans la barre de statue
		window.defaultStatus = this.URLOnClick
}

// METHODE PERMETTANT D'AFFECTER LE STYLE PAR DEFAUT A L'ITEM
function Item_MakeUnfocused()
{
	// Change le style de l'item
	GetElement( "ITEM_" + this.index ).className = this.style

	// Modifie l'image situ� devant le texte de l'item
	if( this.image != "none" && this.imageOnFocus != "none" )
		GetElement( "IMG_ITEM_" + this.index ).src = this.image

	// Modifie l'image de la fl�che
	if( this.imageFleche != "none" && this.imageFlecheOnFocus != "none" )
		GetElement( "FLECHE_ITEM_" + this.index ).src = this.imageFleche

	// L'item doit rediriger la page lors d'un click
	if( this.URLOnClick != "none" )
		// Vide le texte contenu dans la barre de statue
		window.defaultStatus = ""
}



// METHODE INDIQUANT A L'ITEM QU'IL DOIT OUVRIR UN SOUS-MENU
// RETOURNE L'INSTANCE SUR LE SOUS-MENU
function Item_MakeSubMenu( styleMenu, imageFleche )
{
	// M�morise l'image de la fl�che
	if( imageFleche.length > 0 )
		this.imageFleche = imageFleche

	// Cr�e le sous-menu g�r� par l'item
	this.sousMenu = new Menu( this.index, styleMenu )

	// Retourne le nouveau sous-menu
	return this.sousMenu
}

// METHODE PERMETTANT DE DEFINIR UNE IMAGE D'ITEM DIFFERENTE LORSQUE L'ITEM A LE FOCUS
function Item_SetImageOnFocus( image )
{
	this.imageOnFocus = image
}

// METHODE PERMETTANT DE DEFINIR UNE IMAGE DE FLECHE DIFFERENTE LORSQUE L'ITEM A LE FOCUS
function Item_SetFlecheOnFocus( imageFleche )
{
	this.imageFlecheOnFocus = imageFleche
}

// METHODE PERMETTANT DE DEFINIR LA FONCTION JAVASCRIPT QUI SERA APPELEE LORS D'UN CLICK SUR L'ITEM
function Item_SetFunction( functionName )
{
	this.functionOnClick = functionName
}

// METHODE PERMETTANT DE DEFINIR LE LIEN A APPELER LORS D'UN CLICK SUR L'ITEM
function Item_SetURL( linkName )
{
	this.URLOnClick = linkName
}