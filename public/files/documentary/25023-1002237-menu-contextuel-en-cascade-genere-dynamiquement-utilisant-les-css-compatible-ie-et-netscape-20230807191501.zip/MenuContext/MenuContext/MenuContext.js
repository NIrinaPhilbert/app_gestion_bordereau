//////////////////////////////////////////////////////////////////////////////////
//	OBJET	:	Classe et fonctions javascript, permettant la gestion des menus	//
//				contextuels d'une page DHTML									//
//	DATE	:	13 f�vrier 2005													//
//	AUTEUR	:	GOLINSKI Ludwig													//
//////////////////////////////////////////////////////////////////////////////////



// VARIABLE GLOBALE � UTILISER POUR AJOUTER UN MENU CONTEXTUEL
var menuContext = new MenuContext()

// CLASSE PERMETTANT DE STOCKER ET D'ACC�DER AUX MENUS DE LA PAGE AINSI QUE DE CHANGER LE MENU ACTIF
function MenuContext()
{
	// Tableau contenant les menus de la page
	this.tableauMenus = new Array

	// Chaine contenant l'index du menu actif
	this.indexMenuActif = 0

	// M�thodes de la classe
	this.Add = MenuContext_Add
	this.Start = MenuContext_Start
	this.ChangeMenuActif = MenuContext_ChangeMenuActif
}

// M�THODE PERMETTANT D'AJOUTER UN MENU � LA PAGE
function MenuContext_Add( styleMenu )
{
	// Recherche le prochain emplacement libre du tableau
	var indice = 0
	while( this.tableauMenus[ indice ] != null )
		indice ++

	// Cr�e puis stocke le menu vide
	this.tableauMenus[ indice ] = new Menu( indice, styleMenu )

	// Retourne le menu pour pouvoir y ajouter des items
	return this.tableauMenus[ indice ]
}

// FONCTION APPEL�E LORS D'UN CLICK SUR LA PAGE, PERMETTANT DE CACHER LE MENU ACTIF
function HideMenu()
{
	// V�rifie que le menu actif est affich�
	if( menuContext.tableauMenus[ menuContext.indexMenuActif ].isVisible )
	{
		// R�cup�re l'instance sur le menu actif et le cache
		menuContext.tableauMenus[ menuContext.indexMenuActif ].Hide()
	}

	// Retourne false pour que le menu contextuel du navigateur ne se lance pas
	// si la fonction a �t� appel� lors d'un click droit
	return false
}

// FONCTION APPEL�E LORSQUE LE CURSEUR SE D�PLACE SUR LA PAGE, PERMETTANT DE D�TECTER PUIS MODIFIER L'ITEM AYANT LE FOCUS
function FocusChange( evenementSouris )
{
	// Fait appel � la m�thode du menu actif
	menuContext.tableauMenus[ menuContext.indexMenuActif ].FocusChange( evenementSouris )
}

// FONCTION APPEL�E LORSQUE L'UTILISATEUR CLIQUE DANS LA PAGE
function OnSelect( evenementSouris )
{
	// Fait appel � la m�thode du menu actif
	menuContext.tableauMenus[ menuContext.indexMenuActif ].OnSelect( evenementSouris )
}

// FONCTION APPEL�E LORSQUE L'UTILISATEUR COMMENCE UNE S�LECTION OU FAIT UN CLICK DROIT
// ( PERMET D'ARR�TER L'ACTION )
function NoMenu()
{
	return false
}



// M�THODE PERMETTANT DE CONSTRUIRE LES MENUS. A APPELER EN DERNIER POUR QUE LES MENU SOIENT AU PREMIER PLAN
// menuForPage : bool�en indiquant si le menu doit s'afficher lors d'un click droit dans la page
function MenuContext_Start( menuForPage )
{
	// Capture les �v�nements (pour les navigateurs Netscape)
	if( ! document.all )
		document.captureEvents( Event.MOUSEMOVE | Event.CLICK | Event.SELECTSTART )

	// Le menu concerne toute la page
	if( menuForPage )
		document.oncontextmenu = ShowMenu

	// Modifie les fonctions � appeler lorsqu'un �v�nement se produit dans la page
	document.onmousemove = FocusChange
	document.onclick = OnSelect
	document.onselectstart = NoMenu

	// Parcourt le tableau de menus
	var indice = 0
	while( this.tableauMenus[ indice ] != null )
	{
		// Construit le menu ,ces items et ces sous-menus
		this.tableauMenus[ indice ].Draw()

		// Passe au menu suivant
		indice ++
	}
}

// M�THODE PERMETTANT DE CHANGER LE MENU ACTIF C'EST � DIRE, CELUI QUI APPARA�TERA LORS DE L'APPEL A LA FONCTION 'ShowMenu'
function MenuContext_ChangeMenuActif( indexMenuActif )
{
	// Cache le menu actuellement actif
	menuContext.tableauMenus[ menuContext.indexMenuActif ].Hide()

	// Modifie le menu actif
	this.indexMenuActif = indexMenuActif
}


// FONCTION APPEL�E LORS D'UN CLICK DROIT, PERMETTANT D'AFFICHER LE MENU ACTIF
function ShowMenu( evenementSouris )
{
	// Cache puis affiche le menu actif
	menuContext.tableauMenus[ menuContext.indexMenuActif ].Hide()
	menuContext.tableauMenus[ menuContext.indexMenuActif ].Show( evenementSouris )

	// Retourne false pour que le menu contextuel du navigateur ne se lance pas
	return false
}



// FONCTION PERMETTANT D'OBTENIR UN ELEMENT DE LA PAGE, D'APRES SON ID
function GetElement( idElement )
{
	if( document.all )
		return document.all[ idElement ]

	return document.getElementById( idElement )
}